﻿/*
 *author:v-guil
 *email:v-guil@microsoft.com
 *description:
 *      this file defines the schuduler,and the despatch algorithm should be 
 *      added here (It means that you can just modify this file and left others 
 *      unchanged to change the elevators' despatch algorithm)
 **/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewElevatorFramework
{
    class Scheduler
    {
        ButtonPanelOutsideElev[] directionButtonPanels;
        DoorState[][] defenceDoorState;
        IElevator[] elevators;
        int maxFloorCounts;

        //properties
        public ButtonPanelOutsideElev[] DirectionButtons { get { return directionButtonPanels; } }
        public DoorState[][] DefenceDoorState { get { return defenceDoorState; } }
        public int MaxFloorCounts { get { return maxFloorCounts; } }

        //constructor
        public Scheduler(int floorSum) { 
            maxFloorCounts = floorSum;
            directionButtonPanels = new ButtonPanelOutsideElev[maxFloorCounts];
            defenceDoorState = new DoorState[maxFloorCounts][];
            for (int i = 0; i < maxFloorCounts; i++) {
                directionButtonPanels[i] = new ButtonPanelOutsideElev(i);
                //the second dimention of defenceDoorState represents how many defence elevator doors at one floor
                // so it should be initialized at the action of binding with elevators
            }
        }

        //member methods
        public bool bindWithElevators(IElevator[] newElevators)
        {
            if (newElevators == null) {
                Utility.logError("Wrong argument");
                throw new ArgumentNullException();
            }
            elevators = newElevators;
            foreach (var elev in newElevators) {
                elev.addEventListener(EventType.DoorOpen, onElevatorDoorOpen);
                elev.addEventListener(EventType.DoorClose, onElevatorDoorClose);
            }
            //initialize the sizes of defence doors' number of each floor
            for (int i = 0; i < maxFloorCounts; i++) {
                defenceDoorState[i] = new DoorState[elevators.Length]; 
            }
            return true;
        }
        
        //-----------------Here add the schedule algorithm----------------
        public void despatchQueriesToElev() {
            int floor = 0;
            foreach (var panel in directionButtonPanels) {
                if (panel.HasNewlyPressedButton) {
                    //despatch new task outside elevator 

                    //reset notification
                    panel.resetNewlyPressedButtonNotification();
                }
            }

            foreach (var elev in elevators) {
                //----------------here is a naive algorithm of stop at each floor:
                floor = busGen(elev.CurrentDirection, elev.CurrentFloor);
                elev.setTargetFloor(floor);
                //----------------naive algorithm over

                if (elev.ButtonPanel.HasNewlyPressedButton) {
                    //despatch new task inside elevator

                    //reset notification
                    elev.ButtonPanel.resetNewlyPressedButtonNotification(); 
                }
            }
        }
        //generate bus schdule sequence
        private int busGen(Direction direction,int lastFloor) {
            Func<int, int> up = (x => x += 1);
            Func<int, int> down = (x => x -= 1);
            if (direction == Direction.Down) {
                if (lastFloor > 0){
                    return down(lastFloor);
                }
                else{
                    return up(lastFloor);
                }
            }
            else  {
                if (lastFloor < 20)
                {
                    return up(lastFloor);
                }
                else
                {
                    return down(lastFloor);
                }
            }
            return 0;
        }
        //----------------algorithm over----------------------------------

        public List<IButtonPanel> getNewlyPressedButtonPanelsOutside() {
            if (directionButtonPanels == null){
                Utility.logError("No panels outside : Scheduler::getNewlyPressedButtonPanelsOutside");
                throw new InvalidOperationException();
            }

            List<IButtonPanel> list = new List<IButtonPanel>();
            foreach (var panel in directionButtonPanels) {
                if (panel.HasNewlyPressedButton) {
                    list.Add(panel); 
                }  
            }
            return list;
        }

        // check whether the floor is under the control of this scheduler
        public bool checkFloor(int floorNumber) {
            if (floorNumber > maxFloorCounts || floorNumber < 0) {
                return false; 
            }
            return true;
        }

        //event handler
        private void onElevatorDoorOpen(object sender, EventArgs e) {
            abstractDoorEventHandler(sender, e, DoorState.Opened);
        }
        private void onElevatorDoorClose(object sender, EventArgs e) {
            abstractDoorEventHandler(sender, e, DoorState.Closed);            
        }
        private void abstractDoorEventHandler(object sender,EventArgs e,DoorState state) {
            if (sender.GetType() is NewElevatorFramework.IElevator){
                Utility.logWarning("This event is not caused by elevators : Scheduler::abstractDoorEventHandler");
                return; 
            }
            IElevator elev = sender as IElevator;
            int id = elev.ID;
            int stopFloor = elev.CurrentFloor;
            defenceDoorState[stopFloor][id] = state;
        }
    }
}
