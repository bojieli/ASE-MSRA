===============================================================================
Author: v-guil@microsoft.com
date: 2012.11

ElevatorFrameworkStructure.rar:
   This is the UML design graphic of NewElevatorFramework,it is the early work,you may use it as a reference. Although there are many difference in the source code,the basic structure is still the same.

Suggestions.doc:
   This file gives you some suggestions that can help you get familiar with the framework quickly.

Something About NewElevatorFramework:
   This file like a specification but not so official like that.
   The file describe the design concepts of this framework and analysis the details of implementation.If you are puzzled with some source codes in the NewElevatorFramework, maybe you can find answers in this file.
